colors = ['red', 'orange', 'yellow', 'green', 'blue', 'indigo', 'violet']
print("The colors in the Rainbow are: ")
for color in colors:
    print(color)

#SyntaxError: unterminated string literal (detected at line 1)
#there were muliple errors in this code: Blue was missing quotations, the print was missing a indentation, and theres was a extra closing parenthesis.