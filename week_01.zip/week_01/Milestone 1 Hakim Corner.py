# Hakim Corner
# Activity: Chocolate Chip Cookie Recipe

# Prompt the user for the number of chocolate-chip cookies they want to make
num_cookies = int(input("Enter the number of chocolate-chip cookies you want to make: "))

# Variables for chocolate-chip cookies and ingredients
cookies_per_batch = 25
flour_per_batch = 1.3
butter_per_batch = 2.25
sugar_per_batch = 2.55
oil_per_batch = 0.35
chocolate_chips_per_batch = 3

# Calculate the total amount of each ingredient needed
flour_needed = round((flour_per_batch / cookies_per_batch) * num_cookies, 2)
butter_needed = round((butter_per_batch / cookies_per_batch) * num_cookies, 2)
sugar_needed = round((sugar_per_batch / cookies_per_batch) * num_cookies, 2)
oil_needed = round((oil_per_batch / cookies_per_batch) * num_cookies, 2)
chocolate_chips_needed = round((chocolate_chips_per_batch / cookies_per_batch) * num_cookies, 2)

# Output the amount of each ingredient needed
output = "To make {0} chocolate-chip cookies, you will need:\n".format(num_cookies)
output += "- {0} cups of flour\n".format(flour_needed)
output += "- {0} cups of butter\n".format(butter_needed)
output += "- {0} cups of sugar\n".format(sugar_needed)
output += "- {0} cup of vegetable oil\n".format(oil_needed)
output += "- {0} cups of chocolate chips\n".format(chocolate_chips_needed)

print(output)