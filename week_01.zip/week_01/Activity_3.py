# Define variables with numeric values
x = 10
y = 3.5

# Addition
print("Addition:", x + y)

# Subtraction
print("Subtraction:", x - y)

# Multiplication
print("Multiplication:", x * y)

# Division
print("Division:", x / y)

# Exponentiation
print("Exponentiation:", x ** y)

# Modulus
print("Modulus:", x % y)

# Greater Than
print("Greater Than:", x > y)

# Less Than
print("Less Than:", x < y)

# Greater Than or Equal To
print("Greater Than or Equal To:", x >= y)

# Less Than or Equal To
print("Less Than or Equal To:", x <= y)

# Equal To
print("Equal To:", x == y)

# Not Equal To
print("Not Equal To:", x != y)