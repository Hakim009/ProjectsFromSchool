#Part 1
# [STUDENT NAME]
# Python Version 3.x.x
# Activity 2
# Strings

# Assign a string value 'cape canaveral' to the variable 'city'
city = 'cape canaveral'

# Assign a string value 'thrusters' to the variable 'nickname'
nickname = 'thrusters'

# Print a welcome message with the city and the capitalized nickname
print("Welcome to " + city + " home of the " + nickname.capitalize())

# Prompt the user to enter their name and store it in the 'name' variable
name = input("Enter Name: ")

# Print a message introducing the latest player with the title-cased nickname and the title-cased name
print("Introducing the latest " + nickname.title() + " player, " + name.title())





#Part2
string_var = "Hello, world!"
number_var = 42
list_var = [1, 2, 3, 4, 5]
tuple_var = (6, 7, 8, 9, 10)
dictionary_var = {'name': 'John', 'age': 25}

# Get input from the user
user_input_str = input("Enter a string: ")
user_input_num = int(input("Enter a number: "))

# Concatenate and print the values
concatenated_values = string_var + " " + user_input_str + " " + str(number_var + user_input_num)
print("Concatenated values:", concatenated_values)