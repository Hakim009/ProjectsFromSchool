# Student Name
# Python version 3.x.x
# Activity 1

print("Hello World")

