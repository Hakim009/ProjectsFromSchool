import random 

def randopick(L):
    random.shuffle(L)
    return random.choice(L)


def importify(T):
    with open(T, 'r') as f:
        return f.read().splitlines()