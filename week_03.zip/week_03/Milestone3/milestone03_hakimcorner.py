# Hakim Corner
# 3.11.3 
# Pirate Swashbuckle Fight Milestone 3
attack = ['dodge', 'parry', 'thrust']
# 1. Import the Utilities module file
import utilities

# 2. Import the pirates.txt file
with open('pirates.txt', 'r') as file:
    characters = file.read().splitlines()

# 3. Use the utilities module to randomly pick pirates for player and opponent
player = utilities.randopick(characters)
opponent = utilities.randopick(characters)

# 4. Add a while loop so that the pirates are not the same
while player == opponent:
    opponent = utilities.randopick(characters)

print("Advast ye swabs, a fight betwixt \n" + player + " & " + opponent + " 'tis bout to commence! ")

pscore = 0
oscore = 0
gameover = False

while not gameover:
    if pscore >= 3:
        print(player + " has vanquished " + opponent)
        print("Hip hip huzzah!")
        gameover = True
        break
    elif oscore >= 3:
        print(opponent + " has vaquished " + player)
        print("Oh Captain, my Captain!")
        gameover = True
        break

    while True:
        try:
            # 5. Exception / Error handling
            pattack = int(input("Choose your attack (1: dodge, 2: parry, 3: thrust): "))
            if pattack == 1:
                pattack = 'dodge'
                break
            elif pattack == 2:
                pattack = 'parry'
                break
            elif pattack == 3:
                pattack = 'thrust'
                break
            else:
                print("Invalid input. Please enter a number between 1 and 3.")
        except ValueError:
            print("Invalid input. Please enter a number.")

    oattack = utilities.randopick(attack)

    # 7. Add a while loop so that the attacks are not the same. Use the utilities module.
    while pattack == oattack:
        oattack = utilities.randopick(attack)

    print(player + " attacks with a " + pattack)
    print(opponent + " attacks with a " + oattack)

    # 8. Change your if/elif statement
    if (pattack == 'dodge' and oattack == 'parry') or (pattack == 'parry' and oattack == 'thrust') or (pattack == 'thrust' and oattack == 'dodge'):
        pscore += 1
        print(player + " scores a point!")
    elif (oattack == 'dodge' and pattack == 'parry') or (oattack == 'parry' and pattack == 'thrust') or (oattack == 'thrust' and pattack == 'dodge'):
        oscore += 1
        print(opponent + " scores a point!")
    else:
        print("No points scored.")

    # 9. Print a string that includes the player and the player's score.
    print(player + " score: " + str(pscore))

    # 10. Print a string that includes the opponent and the opponent's score.
    print(opponent + " score: " + str(oscore))
