# 1. Comment headers
#
#

# Input / Output

# w write permissions
# w+ write permissions w\create blank doc
# r read only permission
# a append

#######################
# MLB TEAMS
#######################

# 2. Covert the open() function to with open()
# Baseball Team Text file import
with open('mlb-teams.txt', 'r') as f:
    mlb = f.read().splitlines()

# 3. Replace the w+ with the correct option for appending to the file.
with open('mlb-teams.txt', 'a') as f:
    # 4. Using f.write(), add the three teams specified to mlb-teams.txt
    f.write("Seattle Pilots\n")
    f.write("Washington Senators\n")
    f.write("Montreal Expos\n")


#######################
# HALL OF FAME PLAYERS
#######################

favorite_baseball_player = "Old Hoss Radbourne"

with open("hall_of_fame.txt", 'a') as f:
    f.write("Bobby Bonds\n")
    f.write("Al Kaline\n")
    f.write("Mickey Mantle\n")
    f.write("Willie Mays\n")

    # 5. Using the f.write() function, add the player stored in the variable to hall_of_fame.txt
    f.write(favorite_baseball_player + "\n")

    f.write('\n')

# 6. Replace the r with the correct option for appending to the file.
with open('hall_of_fame.txt', 'a') as f:
    # 7. Using the f.write() function, add the 3 players specified to hall_of_fame.txt
    f.write("Babe Ruth\n")
    f.write("Willie Stargell\n")
    f.write("Roberto Clemente\n")

# 8. Import the data from hall_of_fame.txt into a variable called hof_players
with open('hall_of_fame.txt', 'r') as f:
    hof_players = f.read().splitlines()

# 9. Using the list index, print the MLB team closest to your hometown to the screen
print(mlb[18])

# 10. Using the list index, print one of the players in the hof_players variable
print(hof_players[0])