###################################################################################################
# Header Comments
# Author: Hakim Corner
# Date: 6/18/23
# Python Version: 3.11.3
# Assignment: Activity1
###################################################################################################

import time

# Describe how the included countdown(n) script works
# The countdown(n) function takes an integer 'n' as input and starts a countdown from 'n' to 0.
# It prints each number in the countdown and waits for 1 second between each print using the time.sleep(1) function.

def countdown(n):
    while n >= 0:
        print(n)
        time.sleep(1)
        n -= 1

def self_destruct(x):
    authorized_test = "000-Destruct-0"
    authorized_final = "000-Destruct-1"

    # Create variables for the Commanding Officer's Code (co_code), the Executive Officer's Code (xo_code),
    # and the Chief Engineer's Code (ce_code)
    co_code = "111A-Destruct"
    xo_code = "21A2B-Destruct"
    ce_code = "31B2B-Destruct"

    rank = int(input("Select Correct Rank:\n [1] Commanding Officer\n [2] Executive Officer\n [3] Chief Engineer\n RANK: "))

    if rank == 1:
        code = co_code
        print("Commanding Officer Confirmed.")
    elif rank == 2:
        code = xo_code
        print("Executive Officer Confirmed.")
    elif rank == 3:
        code = ce_code
        print("Chief Engineer Confirmed.")
    else:
        print("You are not authorized to initiate Self Destruct.")

    initiate = input("Enter Self Destruct Confirmation Code: ")

    if initiate == code:
        print("Self Destruct Initiate Code: ACCEPTED")
        final_code = input("Enter Activation Code: ")
        if final_code == authorized_final:
            print("Destruct Sequence Confirmed.")
            print(x, " seconds to Self Destruct.")
            print("ALL HANDS ABANDON SHIP - THIS IS NOT A DRILL")
            countdown(x)
            print("Have a nice day!")
            print("BOOM!")
        elif final_code == authorized_test:
            print("Destruct Sequence Test Order Confirmed.")
            print("THIS IS A DRILL - THIS IS A DRILL")
            print("Timer Set to: " + str(x) + " seconds.")
        else:
            print("Destruct Sequence Aborted.")

# Local Variables: authorized_test, authorized_final, rank, code, initiate, final_code, x, co_code, xo_code, ce_code
# Global Variables: time
# Built-in Functions: print, input, int
# Imported Module Functions: sleep (from time module)
# Custom Functions: countdown, self_destruct

# Troubleshooting Solutions:
# 1. Complete header comments at the top of the script.
# 2. The description for the countdown(n) function is already provided and correct.
# 3. The variables for the Commanding Officer's Code, Executive Officer's Code, and Chief Engineer's Code are already created.
# 4. The int() function is used to convert the user's input (rank) into an integer so that it can be compared in the conditional statements.
# 5. The variable x represents the countdown length in seconds. It is passed as an argument to the self_destruct() function to determine the duration of the countdown.
# 6. Local Variables: authorized_test, authorized_final, rank, code, initiate, final_code, x, co_code, xo_code, ce_code
#    Global Variables: time
# 7. Built-in Functions: print, input