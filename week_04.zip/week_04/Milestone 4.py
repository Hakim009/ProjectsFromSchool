# 1.Hakim Corner
# 3.11.1
# Milestone 4


# 4. Create a variable named numbers. It needs to generate a number between 1 to 10.
import random
number = random.randint(1, 10)

# 5. Create a variable named player_name. It needs to prompt the user to enter his/her name.
player_name = input("Enter your name: ")

# 6. Create a variable named number_of_guesses and assign 0 to it.
number_of_guesses = 0

# 7. Print a string that includes the player_name variable. It should say: player_name, I am guessing a number between 1 and 10!
print(player_name + ", I am guessing a number between 1 and 10!")

# 8. Create a WHILE Loop. Give the user 5 attempts to guess the number. If the number is too low print "Your guess is too low". If the number is too high print "Your guess is too high". Create a break if the user answers it correctly.
while number_of_guesses < 5:
    guess = int(input("Guess the number: "))
    number_of_guesses += 1

    if guess < number:
        print("Your guess is too low.")
    elif guess > number:
        print("Your guess is too high.")
    else:
        print("Congratulations! You guessed the number.")
        break

# 9. Verifying if the user has guessed the number or not. If they did, then print a message for them along with the number of tries. If the player couldn't guess the number at the end then print the number along with a message.
if guess == number:
    print("You guessed the number in", number_of_guesses, "tries!")
else:
    print("You couldn't guess the number. The number was", number)
