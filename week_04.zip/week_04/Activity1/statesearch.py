# 1. # Complete the Header Comments and make sure the script executes without error.
#
#

#########################################
# STATE CAPITOL SEARCH
#########################################

# Allow for 5 Searches
# Save Results of search to state_result.txt

# 1. IMPORT THE STATES & CAPITOLS
# 2. Explain why we use an empty dictionary
# A: Starting with an empty dictionary allows us to populate it with state and capital information.

# Create Blank Dictionary
states = {}

# 3. Explain how the FOR Loop is used to import the external data
# A: The for loop iterates over each line in the 'states.txt' file.
#    Each line is split using the comma delimiter, resulting in a key-value pair.
#    The key represents the state, and the value represents the capital.
#    These key-value pairs are then added to the 'states' dictionary.
with open('states.txt', 'r') as f:
    for line in f:
        key, val = line.split(',')
        states[key] = val.strip()

# User must enter the name of the state to search
print('STATE SEARCH SCRIPT')
print('Please enter the name of 5 states to search for.')

# 4. Create a variable called count with an assigned value of 5
count = 5

##########################################
# LOOP THE SEARCH & WRITE TO EXTERNAL FILE
##########################################

# Open Report file
with open('state_results.txt', 'w+') as f:

    # 5. Describe how the WHILE Loop uses the count variable as a control
    # A: The while loop continues as long as the value of 'count' is greater than 0.

    while count > 0:
        search = input('Enter Name of State: ').title()

        # Check the Dictionary for the State / Capitol result
        if search in states:
            print('The Capitol of ' + search + ' is ' + states[search])
            count -= 1
            print('Remaining number of searches:', count)
            f.write('State: ' + search + ' Capitol: ' + states[search] + '\n')
        else:
            print("You have entered an incorrect value.")

###########################################

# 9. Rewrite the LOOP SEARCH section of code to utilize with open()
# Use a Loop to run search 5 times
count = 5
with open('state_results.txt', 'w+') as f:
    while count > 0:
        search = input('Enter Name of State: ').title()

        # Check the Dictionary for the State / Capitol result
        if search in states:
            print('The Capitol of ' + search + ' is ' + states[search])
            count -= 1
            print('Remaining number of searches:', count)
            f.write('State: ' + search + ' Capitol: ' + states[search] + '\n')
        else:
            print("You have entered an incorrect value.")

# 10. Test and confirm your script works before submitting to FSO!