# Hakim Corner
# Python version 3.11.3
# Congress Age Checker 6/11/23

# 1: Variables
age = int(input("Enter Age: "))

# 2. Variables
# Using the above as a guide, complete the following line so that
# "Enter Number of years as a US Citizen: " will appear when the script is executed
citizen = int(input("Enter Number of years as a US Citizen: "))

# 3. Conditional Statement
# Using the variables 'age' & 'citizen', construct a conditional statement that will check if the user is eligible for the Senate, House of Representatives, both, or neither.

if age >= 30 and citizen >= 9:
    print("You are eligible for both the Senate and the House")
elif age >= 25 and citizen >= 7:
    print("You are eligible for the House of Representatives.")
else:
    print("You are ineligible to serve.")
