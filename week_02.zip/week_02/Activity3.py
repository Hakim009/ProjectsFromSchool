# Hakim Corner
# 3.11.3
# Activity3 6/11/23

import random
import time

goodguy = input("Enter your Knight's Name: ")
goodguy = "Sir " + goodguy

# Here, we are assigning the value 'The Black Knight' to the variable badguy
# 1. CHANGE THE LINE BELOW SO THE USER CAN ENTER A VALUE FOR BADGUY
badguy = input("Enter the name of the bad guy: ")
badguy = "Sir " + badguy

# Once Upon A Time...
print(goodguy + ", a Knight in search of adventure, is wandering through the enchanted forest one day.")

# 2. WHAT ACTION DOES time.sleep(2) PERFORM?
# A: time.sleep(2) introduces a delay of 2 seconds in the script's execution, creating a pause.

time.sleep(2)

print("As " + goodguy + " reaches a clearing, he encounters the fearsome " + badguy + "!")

time.sleep(2)

print(goodguy + ": You, Sir, are a Blackguard and a coward! I challenge you to a duel!")
print(badguy + ": I'mma cut you, fool!")

# Good Guy Health
gghealth = 100
# Bad Guy Health
bghealth = 100

# Fight Sequence Loop
while True:
    # 3. EXPLAIN HOW GOODGUY / BADGUY HIT POINTS ARE GENERATED
    # A: The hit points for goodguy (gghit) and badguy (bghit) are generated randomly using the randint() function from the random module.
    # The randint() function generates a random integer within the specified range (inclusive).

    # Good Guy / Bad Guy Hit Points
    gghit = random.randint(1, 100)
    bghit = random.randint(1, 100)

    # 4. WHAT PURPOSE DOES '\n' SERVE?
    # A: '\n' serves as a newline character, creating a line break in the printed output for better readability.

    print("\n")

    # 5. FIND & CORRECT THE SYNTAX ERRORS. COMMENT OUT THE INCORRECT LINES AND
    # WRITE THE CORRECT CODE UNDERNEATH
    print(goodguy + " rolls a " + str(gghit))
    print(badguy + " rolls a " + str(bghit))

    # 6. EXPLAIN HOW THE VALUE IN DAMAGE IS CALCULATED
    # A: The value in damage is calculated by subtracting the smaller hit points from the larger hit points.
    # If gghit is greater than bghit, damage is calculated as gghit - bghit, representing the damage inflicted by goodguy.
    # If bghit is greater than gghit, damage is calculated as bghit - gghit, representing the damage inflicted by badguy.

    # Damage Calculator
    if gghit > bghit:
        damage = gghit - bghit
        bghealth = bghealth - damage
        print(goodguy + " strikes " + badguy + " for a " + str(damage) + " hit!\n")

        if bghealth >= 100:
            print(badguy + ": Thou hast missed.\n")
        elif bghealth >= 75:
            print(badguy + ": Tis but a flesh wound.\n")
        elif bghealth >= 50:
            print(badguy + ": Alas! A fair strike! En garde!\n")
        elif bghealth >= 25:
            print(badguy + ": Thou art a worthy opponent.\n")
        elif bghealth < 10:
            print(badguy + ": I am beaten. Well fought...\n")
            break
    # #######################################################
    elif bghit > gghit:

        damage = bghit - gghit
        gghealth = gghealth - damage

        print(badguy + " strikes " + goodguy + " for a " + str(damage) + " hit!\n")

    # 7. CORRECT THE SYNTAX ERROR(S)
        if gghealth == 100:
            print(goodguy + ": Thou hast missed.\n")
        elif gghealth >= 75:
            print(goodguy + ": Tis but a flesh wound.\n")
        elif gghealth >= 50:
            print(goodguy + ': Alas! A fair strike! En garde!\n')
        elif gghealth >= 25:
            print(goodguy + ": Thou art a worthy opponent.\n")
        elif gghealth < 10:
            print(goodguy + ": I am beaten. Well fought...\n")
            break
    # #######################################################

# END OF LOOP ###############################################

# 8. PRINT A CONGRATULATORY STATEMENT HERE USING THE NAME OF THE WINNER (GOODGUY OR BADGUY)
if bghealth <= 0:
    print("Congratulations, " + goodguy + ", you are the winner!")
else:
    print("Congratulations, " + badguy + ", you are the winner!")

print("End of the Knight Fight\n")

# Answering the questions:
# What condition will end the WHILE Loop?
# The WHILE loop will end when either gghealth or bghealth becomes less than or equal to 0.

# How is that condition handled in the code?
# The condition is checked in the while loop condition itself using the logical operator 'and' to check if both gghealth and bghealth are still greater than 0.

# What events happen inside the WHILE Loop?
# Inside the WHILE loop, the damage is subtracted from the hit points of goodguy (gghealth) and badguy (bghealth), simulating their health decreasing after each round.

# Why are gghealth & bghealth initially set outside the WHILE Loop?
# The initial values of gghealth and bghealth are set outside the WHILE loop to ensure they are assigned before entering the loop. This allows the loop to compare and update their values correctly throughout the iterations.
