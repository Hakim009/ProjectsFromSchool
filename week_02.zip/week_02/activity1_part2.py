# Hakim Corner
# Python version 3.11.3
# Grade Conversion 6/11/23

score = int(input("Enter assignment score: "))

if score >= 95:
    grade = "A+"
elif score >= 90:
    grade = "A"
elif score >= 85:
    grade = "B+"
elif score >= 80:
    grade = "B"
elif score >= 75:
    grade = "C"
elif score >= 70:
    grade = "D"
else:
    grade = "F"

print("You earned a " + grade + " for this assignment.")
