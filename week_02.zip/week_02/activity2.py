zoo = ['Lion', 'Zebra', 'Giraffe', 'Hippo']

for animal in zoo:
    # Error: Missing closing quotation mark for the string
    # Correction: Change "Lion' to 'Lion'
    if animal == 'Lion':
        print("Alex the " + animal)
    # Error: Variable name should be 'animal' instead of 'Animal' (case-sensitive)
    # Correction: Change 'Marty the ' + Animal to 'Marty the ' + animal
    elif animal == 'Zebra':
        print("Marty the " + animal)
    # Error: Variable name should be 'animal' instead of 'animals'
    # Correction: Change 'Melman the ' + animals to 'Melman the ' + animal
    elif animal == 'Giraffe':
        print("Melman the " + animal)
    # Error: None
    # Correction: No correction needed
    elif animal == 'Hippo':
        print("Gloria the " + animal)
# PART2


# Import the Random Module
import random

# Code Name Lists
alpha = ['Crimson', 'Phantom', 'Zephyr', 'Palisade', 'Skyfall']
omega = ['Whirlwind', 'Gatecrasher', 'Iceberg', 'Zealot', 'Element']

# FOR Loop to print 5 random code names
for _ in range(5):
    print(f"Code Name: {random.choice(alpha)} {random.choice(omega)}")
