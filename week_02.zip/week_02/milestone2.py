# Hakim Corner
# 3.11.3
# Milestone2 6/11/23


###### Import the random Module #####
import random

###### Here are your list of Pirates #####
pirates = [
    'Anne Bonny',
    'Captain Henry Morgan',
    'Black Sam Bellamy',
    'Black Bart Roberts',
    'Edward Blackbeard Teach',
    'Captain William Kidd',
    'Pierre Le Grand',
    'Red Leg Grieves',
    'Edward Low',
    'Calico Jack Rackham'
]

#####  Attacks List #####
attack = ['dodge', 'parry', 'thrust']

##### Choosing the Characters for the fight #####
player = random.choice(pirates)
opponent = random.choice(pirates)

##### Announce Game Start #####
print("Ahoy ye swabs! Prepare for battle!")
print(f"{player} has challenged {opponent} in one-on-one combat!")

##### Initialize Scoring Variables ##### 
player_score = 0
opponent_score = 0
gameover = False

# Create a loop that will run UNTIL either the player or opponent scores at least 3 points
# Write your code below this row 👇
while not gameover:
    ##### Choosing the attack #####
    pattack = random.choice(attack)
    oattack = random.choice(attack)

    print(f'{player} attacks with {pattack}, while {opponent} attacks with {oattack}')

    # Add a scoring system to record 1 point for each 'win' scored by either the player or the opponent
    # HINT: You will need to use conditionals to compare the attacks
    # HINT: You will need to update the score variables 
    # Write your code below this row 👇
    if pattack == 'dodge' and oattack == 'parry':
        player_score += 1
        print(f"{player} wins this round!")
    elif pattack == 'parry' and oattack == 'thrust':
        player_score += 1
        print(f"{player} wins this round!")
    elif pattack == 'thrust' and oattack == 'dodge':
        player_score += 1
        print(f"{player} wins this round!")
    elif oattack == 'dodge' and pattack == 'parry':
        opponent_score += 1
        print(f"{opponent} wins this round!")
    elif oattack == 'parry' and pattack == 'thrust':
        opponent_score += 1
        print(f"{opponent} wins this round!")
    elif oattack == 'thrust' and pattack == 'dodge':
        opponent_score += 1
        print(f"{opponent} wins this round!")
    else:
        print("It's a tie! No points awarded.")

    # Create a conditional to determine if the player or opponent has reached a score of 3.
    # Break the loop and end the game if the condition is met.
    # Write your code below this row 👇
    if player_score >= 3 or opponent_score >= 3:
        gameover = True

# Create a conditional outside of the loop to print the winner's name and the final score.
# Write your code below this row 👇
print("Game Over!")
print(f"Final Score: {player} - {player_score}, {opponent} - {opponent_score}")

# Determine the winner of the overall game and congratulate them.
if player_score > opponent_score:
    print(f"{player} is the winner! Congratulations!")
elif opponent_score > player_score:
    print(f"{opponent} is the winner! Congratulations!")
else:
    print("It's a tie! No winner in this game.")

 